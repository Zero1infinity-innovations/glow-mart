@section('bodyContent')
detail pages
@endsection