@extends('admin.layouts.master')
@push('title')
    Dashboard
@endpush
@section('content')
<div class="row">
    <div class="col-6 mb-2">
        <h6 class="mb-0 text-uppercase">Dashboard</h6>
    </div>
    <hr>
</div>
@endsection