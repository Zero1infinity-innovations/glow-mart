<?php $__env->startPush('title'); ?>
    Dashboard
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-6 mb-2">
        <h6 class="mb-0 text-uppercase">Dashboard</h6>
    </div>
    <hr>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\K2\Downloads\admin-panel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>