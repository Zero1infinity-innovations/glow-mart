<?php $__env->startPush('title'); ?>
Product List
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-6">
        <h6 class="mb-0 text-uppercase">Product</h6>
    </div>
    <div class="col-6 text-end px-0 px-lg-3">
        <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-primary btn-sm px-3"><i
                class='bx bx-plus'></i>Add</a>
    </div>
</div>
<hr />
<?php if(session('success')): ?>
    <div class="alert alert-success mt-3 mb-2">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered no-footer" id="categoryList">
                <thead class="table-light">
                    <tr id="thead-html">
                        <th>ID</th>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Sale Price</th>
                        <th>MRP Price</th>
                        <th>Quantity</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Payment Method</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td>
                            <img src="<?php echo e(asset($product->product_image)); ?>" width="50" height="50" alt="Product Image">
                        </td>
                        <td><?php echo e($product->product_name); ?></td>
                        <td><?php echo e($product->sale_price); ?></td>
                        <td><?php echo e($product->mrp_price); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->category ? $product->categoryName->category_name : 'N/A'); ?></td>
                        <td>
                            <?php if($product->product_status == 1): ?>
                            Active
                            <?php else: ?>
                            Inactive
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($product->payment_method == 'cod_only'): ?>
                            COD
                            <?php else: ?>
                            Prepaid
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.product.edit', $product->id)); ?>"
                                class="btn btn-sm btn-warning">Edit</a>

                            <button class="btn btn-sm btn-danger delete-product"
                                data-id="<?php echo e($product->id); ?>">Delete</button>

                            <form id="delete-form-<?php echo e($product->id); ?>"
                                action="<?php echo e(route('admin.product.destroy', $product->id)); ?>" method="POST"
                                style="display:none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center">No products found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-center mt-3">
            <?php echo e($products->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".delete-product").forEach(button => {
        button.addEventListener("click", function() {
            let productId = this.getAttribute("data-id");

            Swal.fire({
                title: "Are you sure?",
                text: "This record will be deleted permanently!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById("delete-form-" + productId).submit();
                }
            });
        });
    });
});
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\K2\Downloads\admin-panel\resources\views/admin/product/index.blade.php ENDPATH**/ ?>