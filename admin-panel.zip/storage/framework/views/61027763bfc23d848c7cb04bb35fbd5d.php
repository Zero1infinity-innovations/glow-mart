<?php $__env->startPush('title'); ?>
Product List
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-6">
        <h6 class="mb-0 text-uppercase">Shops</h6>
    </div>
    <div class="col-6 text-end px-0 px-lg-3">
        <a href="<?php echo e(route('admin.shops.create')); ?>" class="btn btn-primary btn-sm px-3"><i
                class='bx bx-plus'></i>Add</a>
    </div>
</div>
<hr />
<?php if(session('success')): ?>
<div class="alert alert-success mt-3 mb-2">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered no-footer" id="categoryList">
                <thead class="table-light">
                    <tr id="thead-html">
                    <tr>
                        <th>ID</th>
                        <th>Shop Image</th>
                        <th>Shop Name</th>
                        <th>Owner Name</th>
                        <th>Owner Email</th>
                        <th>City</th>
                        <th>Pincode</th>
                        <th>Actions</th>
                    </tr>
                    </tr>
                </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($shop->id); ?></td>
                        <td>
                            <img src="<?php echo e(asset($shop->shop_image)); ?>" style="border-radius:50px;" width="50" height="50" alt="Shop Image">
                        </td>
                        <td><?php echo e($shop->shop_name); ?></td>
                        <td><?php echo e($shop->owner_name); ?></td>
                        <td><?php echo e($shop->owner_email); ?></td>
                        <td><?php echo e($shop->city); ?></td>
                        <td><?php echo e($shop->pincode); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.shops.edit', $shop->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('admin.shops.destroy', $shop->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center">No Shop Record.</td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".delete-product").forEach(button => {
        button.addEventListener("click", function() {
            let productId = this.getAttribute("data-id");

            Swal.fire({
                title: "Are you sure?",
                text: "This record will be deleted permanently!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById("delete-form-" + productId).submit();
                }
            });
        });
    });
});
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\K2\Downloads\admin-panel\resources\views/admin/shops/index.blade.php ENDPATH**/ ?>