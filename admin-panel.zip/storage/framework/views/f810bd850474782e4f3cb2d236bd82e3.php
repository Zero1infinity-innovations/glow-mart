 
<script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="<?php echo e(asset('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('customJs/common.js')); ?>"></script><?php /**PATH C:\Users\K2\Downloads\admin-panel\resources\views/admin/layouts/script.blade.php ENDPATH**/ ?>