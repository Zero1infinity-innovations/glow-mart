<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <?php echo $__env->make('layout.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <body>
        <?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('bodyContent'); ?>

        <!-- Back to Top -->
        <a href="https://wa.me/919876543210" class="btn back-to-top" target="_blank">
            <i class="fa-brands fa-whatsapp"
                style="background-color: #25D366; padding: 10px; border-radius: 50%; color: white;"></i>
        </a>
        
        <?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scriptJs'); ?>
</html>
<?php /**PATH C:\Users\K2\Downloads\admin-panel\resources\views/layout/index.blade.php ENDPATH**/ ?>