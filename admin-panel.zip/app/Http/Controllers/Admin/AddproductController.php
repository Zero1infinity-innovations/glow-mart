<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Validation\Rule;

class AddproductController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        $products = Product::with('categoryName')->orderBy('id', 'desc')->paginate(10);
        // echo '<pre>';print_r($products[0]->categoryName->category_name);exit;
        return view('admin.product.index', compact('products', 'categories'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('admin.product.create', compact('categories'));
    }

    public function store(Request $request)
    {
        // $request->validate([
        //     'product_name'      => 'required|string|max:255',
        //     'sale_price'        => 'required',
        //     'mrp_price'         => 'required',
        //     'quantity'          => 'required',
        //     'product_image'     => 'image|mimes:jpeg,png,jpg|max:2048',
        //     'product_gallery'   => 'image|mimes:jpeg,png,jpg|max:2048',
        //     'category'          => 'required',
        //     'product_status'    => 'required',
        //     'payment_method'    => 'required',
        //     'description'       => 'nullable',
        // ]);

        // Ensure the directories exist
        if (!file_exists(public_path('assets/products'))) {
            mkdir(public_path('assets/products'), 0777, true);
        }
        if (!file_exists(public_path('assets/products/gallery'))) {
            mkdir(public_path('assets/products/gallery'), 0777, true);
        }

        // Handle main product image
        $productImage = $request->file('product_image');
        $productImageName = time() . '_' . $productImage->getClientOriginalName();
        $productImage->move(public_path('assets/products'), $productImageName);
        $productImagePath = 'assets/products/' . $productImageName;

        // Handle gallery images
        $galleryImages = [];
        if ($request->hasFile('product_gallery')) {
            foreach ($request->file('product_gallery') as $image) {
                $galleryImageName = time() . '_' . $image->getClientOriginalName();
                $image->move(public_path('assets/products/gallery'), $galleryImageName);
                $galleryImages[] = 'assets/products/gallery/' . $galleryImageName;
            }
        }

        // Save product data
        $product = new Product();
        $product->product_name          = $request->product_name;
        $product->sale_price            = $request->sale_price;
        $product->mrp_price             = $request->mrp_price;
        $product->quantity              = $request->quantity;
        $product->product_image         = $productImagePath;
        $product->product_gallery       = json_encode($galleryImages);
        $product->category              = $request->category;
        $product->subcategory           = $request->subcategory;
        $product->product_status        = $request->product_status;
        $product->payment_method        = $request->payment_method;
        $product->description           = $request->description;

        if ($product->save()) {
            return redirect()->route('admin.product.index')->with('success', 'Product added successfully');
        } else {
            return back()->with('error', 'Failed to save product');
        }
    }

    public function edit($id)
    {
        $product = Product::findOrFail($id);
        $categories = Category::all();
        $subCategory = SubCategory::all();
        $selectedCategoryId = $product->category;
        $selectedSubcategoryId = $product->subcategory;
        return view('admin.product.edit', compact('product', 'categories', 'subCategory',  'selectedCategoryId', 'selectedSubcategoryId'));
    }

    public function update(Request $request, $id)
    {
        // $request->validate([
        //     'product_name'      => 'required|string|max:255',
        //     'sale_price'        => 'required|numeric',
        //     'mrp_price'         => 'required|numeric',
        //     'quantity'          => 'required|integer',
        //     'category'          => 'required|integer',
        //     'product_status'    => 'required|string',
        //     'payment_method'    => 'required|string',
        //     'description'       => 'nullable|string',
        // ]);

        $product = Product::findOrFail($id);

        if ($request->hasFile('product_image')) {
            $productImage = $request->file('product_image');
            $productImageName = time() . '_' . $productImage->getClientOriginalName();
            $productImage->move(public_path('assets/products'), $productImageName);
            $product->product_image = 'assets/products/' . $productImageName;
        }

        $galleryImages = json_decode($product->product_gallery, true) ?? [];
        if ($request->hasFile('product_gallery')) {
            foreach ($request->file('product_gallery') as $image) {
                $galleryImageName = time() . '_' . $image->getClientOriginalName();
                $image->move(public_path('assets/products/gallery'), $galleryImageName);
                $galleryImages[] = 'assets/products/gallery/' . $galleryImageName;
            }
            $product->product_gallery = json_encode($galleryImages);
        }

        $product->product_name      = $request->product_name;
        $product->sale_price        = $request->sale_price;
        $product->mrp_price         = $request->mrp_price;
        $product->quantity          = $request->quantity;
        $product->category          = $request->category;
        $product->subcategory       = $request->subcategory;
        $product->product_status    = $request->product_status;
        $product->payment_method    = $request->payment_method;
        $product->description       = $request->description;

        if ($product->save()) {
            return redirect()->route('admin.product.index')->with('success', 'Product updated successfully');
        } else {
            return back()->with('error', 'Failed to update product');
        }
    }

    public function destroy($id)
    {
        $product = Product::find($id);
        $product->delete();
        return redirect()->route('product.index')->with('success', 'Product deleted successfully');
    }

    public function getSubcategories(Request $request)
    {
        $subcategories = SubCategory::where('parent_cate_id', $request->category_id)->get();
        return response()->json($subcategories);
    }

}
