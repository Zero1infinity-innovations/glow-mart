<?php

return [
    App\Providers\AppServiceProvider::class,
    Intervention\Image\ImageServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
];
